(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global.ooapp = {})));
}(this, (function (exports) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */













function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

const js = {
    elements_ooapp_co_stable_oo_elements: '//elements.ooapp.co/stable/oo-elements.js'
};
const css = {
    fonts_google_roboto: '//fonts.googleapis.com/css?family=Roboto:100,400'
};

var ooElements = () => {
    return `<script async src="${js.elements_ooapp_co_stable_oo_elements}"></script>`;
};

var _html = (opts) => {
    const { head, body } = opts;
    return `
<!doctype html>
<html lang="en">
	${head}
	<body>
		${body}
		${ooElements()}
	</body>
</html>`;
};

var _head = (opts) => {
    const { title } = opts;
    return `
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>${title}</title>
	<link rel="preload" as="script" href="${js.elements_ooapp_co_stable_oo_elements}">
	<link rel="preload" as="style" href="${css.fonts_google_roboto}">
	<link href="${css.fonts_google_roboto}" rel="stylesheet">
	<style>body {
	margin: 0;
}
main {
	display: -webkit-box;
	display: -ms-flexbox;
	display: flex;
	-webkit-box-pack: center;
	    -ms-flex-pack: center;
	        justify-content: center;
	-ms-flex-wrap: wrap;
	    flex-wrap: wrap;
	-webkit-box-sizing: border-box;
	        box-sizing: border-box;
}
oo-footer {
	-ms-flex-item-align: end;
	    align-self: flex-end;
	width: 100%;
}
.container {
	display: -webkit-box;
	display: -ms-flexbox;
	display: flex;
	-webkit-box-orient: vertical;
	-webkit-box-direction: normal;
	    -ms-flex-direction: column;
	        flex-direction: column;
}
.container main {
		-webkit-box-flex: 1;
		    -ms-flex-positive: 1;
		        flex-grow: 1;
	}
@media (min-width: 768px) {
	.container {
		-webkit-box-orient: horizontal;
		-webkit-box-direction: normal;
		    -ms-flex-direction: row;
		        flex-direction: row;
	}
}
oo-nav {
	height: 100vh;
    width: 200px;
}
	</style>
</head>`;
};

var notFound = () => {
    const body = `
<style>main {
	height: 100vh;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;
}
span {
	font-family: sans-serif;
	padding: 16px;
	padding: 1rem
}
span:first-child {
	font-weight: 700;
	font-size: 48px;
	font-size: 3rem;
}
</style>
<main>
	<span class=404>404</span>
	<span class=not-found>Not found</span>
</main>
`;
    const head = _head({ title: '404 Not found' });
    const html = _html({ head, body });
    return {
        status: 404,
        body: html
    };
};

var _footer = () => {
    return `
<oo-footer>
	<a slot=item href="/first">First</a>
	<a slot=item href="/second">Second</a>
	<a slot=item href="/third">Third</a>
</oo-footer>`;
};

var title = (title) => {
    return `Double O - ${title}`;
};

var sign = (paths) => {
    const [resource] = paths;
    if (paths.length > 1) {
        return notFound();
    }
    const body = `
<style>main {
	height: 100vh;
	-webkit-box-orient: vertical;
	-webkit-box-direction: normal;
	    -ms-flex-direction: column;
	        flex-direction: column;
}
.signins {
	display: -webkit-box;
	display: -ms-flexbox;
	display: flex;
	-webkit-box-orient: vertical;
	-webkit-box-direction: normal;
	    -ms-flex-direction: column;
	        flex-direction: column;
	-webkit-box-flex: 1;
	    -ms-flex-positive: 1;
	        flex-grow: 1;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;
	-webkit-box-pack: center;
	    -ms-flex-pack: center;
	        justify-content: center;
}
.signins .buttons {
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		    -ms-flex-direction: column;
		        flex-direction: column;
		-webkit-box-align: stretch;
		    -ms-flex-align: stretch;
		        align-items: stretch;
		-webkit-transform: scale(1.4);
		        transform: scale(1.4);
	}
oo-sign-in {
	width: 100%;
	height: 64px;
	height: 4rem
}
oo-sign-in:not(:last-child) {
	margin-bottom: 16px;
	margin-bottom: 1rem;
}
</style>
<main ${resource}>
	<div class=signins>
		<div class=buttons>
			<oo-sign-in data-provider=google></oo-sign-in>
			<oo-sign-in data-provider=facebook></oo-sign-in>
			<oo-sign-in data-provider=github></oo-sign-in>
		</div>
	</div>
	${_footer()}
</main>
	`;
    const head = _head({ title: title('Sign In/Sign Up') });
    const html = _html({ head, body });
    return {
        status: 200,
        body: html
    };
};

var user = (paths) => {
    return notFound();
};

var script = `
<script>
	(() => {
		const uid = window.localStorage.getItem('oo:uid')
		window.document.querySelectorAll('a[href*="@UID@"]').forEach(el => {
			el.setAttribute('href', el.getAttribute('href').replace('@UID@', uid))
		})
	})()
</script>
`;

var dashboard = (paths) => {
    if (paths.length > 1) {
        return notFound();
    }
    const body = `
<style>main {
	height: 100vh;
	-webkit-box-orient: vertical;
	-webkit-box-direction: normal;
	    -ms-flex-direction: column;
	        flex-direction: column;
}
.links {
	display: -webkit-box;
	display: -ms-flexbox;
	display: flex;
	-webkit-box-orient: vertical;
	-webkit-box-direction: normal;
	    -ms-flex-direction: column;
	        flex-direction: column;
	-webkit-box-flex: 1;
	    -ms-flex-positive: 1;
	        flex-grow: 1;
    -webkit-box-align: center;
        -ms-flex-align: center;
            align-items: center;
	-webkit-box-pack: center;
	    -ms-flex-pack: center;
	        justify-content: center;
}
.links a {
		text-decoration: none;
		font-family: Roboto, sans-serif;
		padding: 48px;
		padding: 3rem;
		font-size: 48px;
		font-size: 3rem;
		font-weight: 100;
		color: inherit;
		-webkit-tap-highlight-color: transparent;
		-webkit-transition: -webkit-box-shadow 0.5s, -webkit-transform 0.5s;
		transition: -webkit-box-shadow 0.5s, -webkit-transform 0.5s;
		transition: box-shadow 0.5s, transform 0.5s;
		transition: box-shadow 0.5s, transform 0.5s, -webkit-box-shadow 0.5s, -webkit-transform 0.5s
	}
.links a:hover {
	-webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .18824), 0 16px 84px rgba(0, 0, 0, .12549);
	        box-shadow: 0 1px 1px rgba(0, 0, 0, .18824), 0 16px 84px rgba(0, 0, 0, .12549);
	-webkit-transform: translateY(-5px);
	        transform: translateY(-5px);
}
</style>
<main>
	<div class=links>
		<a href=@UID@/projects slot=item>Projects</a>
		<a href=@UID@/settings slot=item>Settings</a>
	</div>
	${_footer()}
</main>
${script}
	`;
    const head = _head({ title: title('Dashboard') });
    const html = _html({ head, body });
    return {
        status: 200,
        body: html
    };
};

var app = (paths) => {
    const [resource] = paths;
    switch (resource) {
        case 'sign':
            return sign(paths);
        case 'dashboard':
            return dashboard(paths);
        default:
            return user(paths);
    }
};

const handler = (event, _, callback) => __awaiter(undefined, void 0, void 0, function* () {
    const paths = event.path.replace(/^\//, '').split('/');
    const result = yield app(paths);
    const { err = null, status: statusCode, body } = result;
    callback(err, {
        statusCode,
        body,
        headers: {
            'content-type': 'text/html; charset=utf-8'
        }
    });
});

exports.handler = handler;

Object.defineProperty(exports, '__esModule', { value: true });

})));
